# Как залить проект на GitHub с телефона через Codespaces

1. Открой репозиторий:
   https://github.com/wwgame28/perimeter

2. Нажми **Code** → **Codespaces** → **Create codespace on main**.

3. В Codespaces загрузи файл `perimeter_github_ready.zip`.

4. В терминале Codespaces выполни:

```bash
unzip perimeter_github_ready.zip
cp -r perimeter_github_ready/* .
git add .
git commit -m "Initial project"
git push
```

Если GitHub скажет, что нечего коммитить — значит файлы уже добавлены.
