
import os
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
import asyncio

BOT_TOKEN = os.getenv("BOT_TOKEN")

dp = Dispatcher()

@dp.message(Command("start"))
async def start(message: types.Message):
    await message.answer("Добро пожаловать в «Периметр». Команда: /play")

@dp.message(Command("play"))
async def play(message: types.Message):
    await message.answer("Сцены лежат в папке docs. Это MVP-бот для дальнейшей интеграции сценария.")

async def main():
    if not BOT_TOKEN:
        raise RuntimeError("Set BOT_TOKEN environment variable")
    bot = Bot(BOT_TOKEN)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
